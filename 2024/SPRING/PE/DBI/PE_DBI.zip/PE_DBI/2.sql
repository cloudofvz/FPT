﻿SELECT code_product as N'Mã sản phẩm', 
	product_name as N'Tên sản phẩm',
	quantity*price as N'Tổng tiền tồn kho (VND)' 
FROM product